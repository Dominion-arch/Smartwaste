# SmartWaste — Setup & Credential Guide

## How to Run
Open `index.html` in any modern browser. No server required — all data uses localStorage.

## File Structure
```
smartwaste/
├── index.html          ← Portal selection landing page
├── login.html          ← Shared login page (all roles)
├── main.css            ← Shared stylesheet
├── js/
│   ├── auth.js         ← Authentication & user management
│   ├── data.js         ← Live IoT simulation engine
│   ├── charts.js       ← Canvas chart library
│   └── map.js          ← Canvas city map
├── admin/
│   ├── index.html      ← Operations dashboard
│   ├── bins.html       ← Bin monitor
│   ├── routes.html     ← Route overview
│   ├── reports.html    ← Environmental reports
│   └── alerts.html     ← Alert management
├── driver/
│   └── index.html      ← Driver app (stops, map, stats)
└── citizen/
    └── index.html      ← Citizen app (report, pickup, eco)
```

## Credentials

### Admin
| Username | Password       |
|----------|----------------|
| admin    | smartwaste7335 |

Admin can: view all dashboards, create/delete driver accounts.

### Drivers (pre-seeded, admin can add more)
| Username    | Password    | Truck  | Route   | Zone              |
|-------------|-------------|--------|---------|-------------------|
| kwame.a     | driver1234  | TRK-01 | Route A | Osu               |
| ama.boateng | driver1234  | TRK-02 | Route B | Labone            |
| kofi.s      | driver1234  | TRK-03 | Route C | East Legon        |

### Citizens (pre-seeded, anyone can self-register)
| Username   | Password    | Zone          |
|------------|-------------|---------------|
| abena.m    | citizen123  | East Legon    |
| yaw.darko  | citizen123  | Accra Central |

Citizens can register their own accounts via the "Create a citizen account" link on the login page.

## Authentication Rules
- **Admin** → only one admin account; username `admin`, password `smartwaste7335`
- **Drivers** → accounts created exclusively by the admin via the "Drivers" panel in the admin dashboard
- **Citizens** → self-registration open to anyone via the login page
- Each role is guarded: accessing a portal with the wrong role redirects to login
- Sessions persist in localStorage until "Sign Out" is clicked

## localStorage Keys Used
| Key                      | Contents                         |
|--------------------------|----------------------------------|
| `sw_users`               | All user accounts (JSON array)   |
| `sw_session`             | Current logged-in user           |
| `sw_ctz_{userId}`        | Citizen reports, pickups, activity |
| `sw_collected_{driverId}_{date}` | Driver's collected bins today |

## Live Data
Bins update every 8 seconds (fill levels rise, trucks move). All 80 bins and 6 trucks are simulated.
City can be switched via the dropdown in the admin sidebar.
