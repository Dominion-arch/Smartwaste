/* ============================================================
   SmartWaste — Auth Engine (localStorage-based)
   Roles: admin | driver | citizen
   ============================================================ */

const SWAuth = (function () {

  const STORAGE_KEYS = {
    users:   'sw_users',
    session: 'sw_session',
    drivers: 'sw_drivers',  // admin-managed driver accounts
  };

  // ── Seed built-in accounts on first load ──────────────────
  function seedData() {
    if (localStorage.getItem(STORAGE_KEYS.users)) return; // already seeded

    const defaultUsers = [
      {
        id: 'admin-001',
        username: 'admin',
        password: 'smartwaste7335',
        role: 'admin',
        name: 'City Administrator',
        email: 'admin@smartwaste.gh',
        createdAt: new Date('2025-01-15').toISOString(),
        avatar: '◈',
      },
      // Pre-seeded driver accounts (created by admin)
      {
        id: 'drv-001',
        username: 'kwame.a',
        password: 'driver1234',
        role: 'driver',
        name: 'Kwame Asante',
        email: 'kwame.a@smartwaste.gh',
        createdAt: new Date('2025-03-10').toISOString(),
        truckId: 'TRK-01',
        route: 'Route A',
        zone: 'Osu',
        avatar: '🚛',
        binsCollectedTotal: 312,
        efficiency: 94,
      },
      {
        id: 'drv-002',
        username: 'ama.boateng',
        password: 'driver1234',
        role: 'driver',
        name: 'Ama Boateng',
        email: 'ama.b@smartwaste.gh',
        createdAt: new Date('2025-03-12').toISOString(),
        truckId: 'TRK-02',
        route: 'Route B',
        zone: 'Labone',
        avatar: '🚛',
        binsCollectedTotal: 287,
        efficiency: 91,
      },
      {
        id: 'drv-003',
        username: 'kofi.s',
        password: 'driver1234',
        role: 'driver',
        name: 'Kofi Sarpong',
        email: 'kofi.s@smartwaste.gh',
        createdAt: new Date('2025-04-01').toISOString(),
        truckId: 'TRK-03',
        route: 'Route C',
        zone: 'East Legon',
        avatar: '🚛',
        binsCollectedTotal: 198,
        efficiency: 88,
      },
      // Pre-seeded citizen accounts
      {
        id: 'ctz-001',
        username: 'abena.m',
        password: 'citizen123',
        role: 'citizen',
        name: 'Abena Mensah',
        email: 'abena.m@gmail.com',
        createdAt: new Date('2025-02-20').toISOString(),
        zone: 'East Legon',
        avatar: '📱',
        ecoScore: 840,
        reportsSubmitted: 7,
        pickupsScheduled: 3,
      },
      {
        id: 'ctz-002',
        username: 'yaw.darko',
        password: 'citizen123',
        role: 'citizen',
        name: 'Yaw Darko',
        email: 'yaw.d@yahoo.com',
        createdAt: new Date('2025-04-05').toISOString(),
        zone: 'Accra Central',
        avatar: '📱',
        ecoScore: 510,
        reportsSubmitted: 4,
        pickupsScheduled: 1,
      },
    ];

    localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(defaultUsers));
  }

  // ── Helpers ──────────────────────────────────────────────
  function getUsers() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.users) || '[]');
  }

  function saveUsers(users) {
    localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
  }

  function getSession() {
    const s = localStorage.getItem(STORAGE_KEYS.session);
    return s ? JSON.parse(s) : null;
  }

  function saveSession(user) {
    const session = { ...user, loginTime: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.session, JSON.stringify(session));
  }

  function clearSession() {
    localStorage.removeItem(STORAGE_KEYS.session);
  }

  // ── Auth Actions ──────────────────────────────────────────
  function login(username, password) {
    const users = getUsers();
    const user = users.find(u =>
      u.username.toLowerCase() === username.toLowerCase() && u.password === password
    );
    if (!user) return { ok: false, error: 'Invalid username or password.' };
    saveSession(user);
    return { ok: true, user };
  }

  function logout() {
    clearSession();
  }

  function register(data) {
    // Citizens only — drivers are admin-created
    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === data.username.toLowerCase())) {
      return { ok: false, error: 'Username already taken.' };
    }
    if (users.find(u => u.email.toLowerCase() === data.email.toLowerCase())) {
      return { ok: false, error: 'Email already registered.' };
    }
    const newUser = {
      id: 'ctz-' + Date.now(),
      username: data.username,
      password: data.password,
      role: 'citizen',
      name: data.name,
      email: data.email,
      createdAt: new Date().toISOString(),
      zone: data.zone || 'Accra Central',
      avatar: '📱',
      ecoScore: 0,
      reportsSubmitted: 0,
      pickupsScheduled: 0,
    };
    users.push(newUser);
    saveUsers(users);
    saveSession(newUser);
    return { ok: true, user: newUser };
  }

  function adminCreateDriver(data) {
    // Only admin can call this; check session
    const session = getSession();
    if (!session || session.role !== 'admin') return { ok: false, error: 'Unauthorized.' };

    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === data.username.toLowerCase())) {
      return { ok: false, error: 'Username already taken.' };
    }

    const newDriver = {
      id: 'drv-' + Date.now(),
      username: data.username,
      password: data.password,
      role: 'driver',
      name: data.name,
      email: data.email || '',
      createdAt: new Date().toISOString(),
      truckId: data.truckId || 'TRK-XX',
      route: data.route || 'Route X',
      zone: data.zone || '',
      avatar: '🚛',
      binsCollectedTotal: 0,
      efficiency: 85,
    };
    users.push(newDriver);
    saveUsers(users);
    return { ok: true, user: newDriver };
  }

  function deleteDriver(driverId) {
    const session = getSession();
    if (!session || session.role !== 'admin') return { ok: false, error: 'Unauthorized.' };
    let users = getUsers();
    const driver = users.find(u => u.id === driverId && u.role === 'driver');
    if (!driver) return { ok: false, error: 'Driver not found.' };
    users = users.filter(u => u.id !== driverId);
    saveUsers(users);
    return { ok: true };
  }

  function getDrivers() {
    return getUsers().filter(u => u.role === 'driver');
  }

  function getCitizens() {
    return getUsers().filter(u => u.role === 'citizen');
  }

  // ── Route Guard ───────────────────────────────────────────
  // Call at top of each portal page: requireRole('admin') etc.
  function requireRole(role) {
    const session = getSession();
    if (!session) {
      window.location.href = getLoginUrl(role);
      return null;
    }
    if (session.role !== role) {
      // Redirect to their correct portal
      redirectToPortal(session.role);
      return null;
    }
    return session;
  }

  function getLoginUrl(role) {
    const depth = window.location.pathname.split('/').filter(Boolean).length;
    const prefix = depth <= 1 ? '' : '../';
    return `${prefix}login.html?portal=${role || 'citizen'}`;
  }

  function redirectToPortal(role) {
    const depth = window.location.pathname.split('/').filter(Boolean).length;
    const prefix = depth <= 1 ? '' : '../';
    const map = { admin: 'admin/index.html', driver: 'driver/index.html', citizen: 'citizen/index.html' };
    window.location.href = prefix + (map[role] || '');
  }

  // ── Public API ───────────────────────────────────────────
  function init() { seedData(); }

  return {
    init, login, logout, register,
    adminCreateDriver, deleteDriver,
    getSession, getDrivers, getCitizens, getUsers,
    requireRole, redirectToPortal,
  };

})();

// Auto-init on load
SWAuth.init();
