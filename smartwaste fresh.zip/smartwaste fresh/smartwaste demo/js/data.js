/* ============================================================
   SmartWaste — Data Engine
   Live IoT simulation: bins fill over time
   ============================================================ */

const SW = (function() {

  const CITIES = {
    accra:     { name: 'Accra, Ghana',    zones: ['Osu','Labone','Cantonments','Airport Residential','East Legon','Tema','Madina','Accra Central'] },
    nairobi:   { name: 'Nairobi, Kenya',  zones: ['Westlands','Kilimani','CBD','Karen','Eastlands','Parklands','South B','Embakasi'] },
    lagos:     { name: 'Lagos, Nigeria',  zones: ['Victoria Island','Lekki','Ikeja','Surulere','Yaba','Apapa','Maryland','Ikoyi'] },
    cape_town: { name: 'Cape Town, SA',   zones: ['CBD','Green Point','Observatory','Claremont','Woodstock','Bellville','Mitchells Plain','Khayelitsha'] },
    london:    { name: 'London, UK',      zones: ['Westminster','Southwark','Hackney','Camden','Tower Hamlets','Islington','Lambeth','Wandsworth'] },
  };

  const BIN_TYPES    = ['General','Recycling','Organic','Hazardous','Glass'];
  const DRIVERS      = ['Kwame A.','Ama B.','Kofi S.','Abena M.','Yaw D.','Efua T.'];
  const TRUCK_COLORS = ['#b57bee','#3d9eff','#f5a623','#00e5a0','#ff4757','#e8edf5'];

  let currentCity = 'accra';
  let bins = [], trucks = [], alerts = [];
  let updateCallbacks = [];
  let tickInterval = null;

  function seededRand(seed, min, max) {
    const x = Math.sin(seed * 9301 + 49297) * 233280;
    return Math.floor((x - Math.floor(x)) * (max - min + 1)) + min;
  }
  function rand(min, max)   { return Math.floor(Math.random() * (max - min + 1)) + min; }
  function randF(min, max)  { return parseFloat((Math.random() * (max - min) + min).toFixed(3)); }

  function generateBins(cityKey) {
    const city = CITIES[cityKey];
    bins = [];
    for (let i = 0; i < 80; i++) {
      const s = i * 17 + cityKey.length * 31;
      bins.push({
        id:         `BIN-${cityKey.toUpperCase().slice(0,3)}-${String(i+1).padStart(3,'0')}`,
        zone:       city.zones[seededRand(s,    0, city.zones.length - 1)],
        type:       BIN_TYPES[seededRand(s+1,   0, BIN_TYPES.length - 1)],
        fill:       rand(10, 80),
        fillRate:   randF(0.05, 0.45),   // % added every 8s tick
        lat:        randF(-0.95, 0.95),
        lng:        randF(-0.95, 0.95),
        lastUpdate: new Date(),
        sensorOk:   seededRand(s+2, 0, 19) > 0,  // ~5% offline
        capacity:   240,
        temperature: seededRand(s+3, 18, 42),
      });
    }
    return bins;
  }

  function generateTrucks(cityKey) {
    const city = CITIES[cityKey];
    trucks = [];
    for (let i = 0; i < 6; i++) {
      const s = i * 23 + cityKey.length * 7;
      trucks.push({
        id:               `TRK-0${i+1}`,
        driver:           DRIVERS[i],
        zone:             city.zones[i % city.zones.length],
        lat:              randF(-0.7, 0.7),
        lng:              randF(-0.7, 0.7),
        status:           ['Active','Active','Active','Active','Returning','Idle'][i],
        binsCollected:    rand(5, 18),
        route:            `Route ${String.fromCharCode(65+i)}`,
        efficiency:       seededRand(s, 72, 97),
        color:            TRUCK_COLORS[i],
        fuelLevel:        seededRand(s+1, 35, 95),
        distanceKm:       parseFloat((rand(8,28) + Math.random()).toFixed(1)),
        estMinsRemaining: rand(20, 90),
        nextStop:         null,         // set to nearest high-fill bin
      });
    }
    assignNextStops();
    return trucks;
  }

  function assignNextStops() {
    const highBins = bins.filter(b => b.fill >= 70 && b.sensorOk);
    trucks.forEach(truck => {
      if (truck.status !== 'Active') { truck.nextStop = null; return; }
      // find nearest high-fill bin in truck's zone (fall back to any)
      const zoneBins = highBins.filter(b => b.zone === truck.zone);
      const pool = zoneBins.length ? zoneBins : highBins;
      if (!pool.length) { truck.nextStop = null; return; }
      let best = null, bestD = Infinity;
      pool.forEach(b => {
        const d = Math.hypot(b.lat - truck.lat, b.lng - truck.lng);
        if (d < bestD) { best = b; bestD = d; }
      });
      truck.nextStop = best ? best.id : null;
    });
  }

  function buildAlerts() {
    alerts = [];
    bins.filter(b => b.fill >= 90 && b.sensorOk).slice(0, 8).forEach((b, i) => {
      alerts.push({ id:`OVF-${i}`, type:'danger', icon:'🔴', title:'Bin Overflow',
        detail:`${b.id} in ${b.zone} at ${b.fill.toFixed(0)}%`,
        time: new Date(Date.now() - rand(30000, 900000)), read: false, binId: b.id, zone: b.zone });
    });
    bins.filter(b => b.fill >= 75 && b.fill < 90 && b.sensorOk).slice(0, 6).forEach((b, i) => {
      alerts.push({ id:`HIGH-${i}`, type:'warn', icon:'🟡', title:'High Fill Level',
        detail:`${b.id} in ${b.zone} at ${b.fill.toFixed(0)}%`,
        time: new Date(Date.now() - rand(300000, 5400000)), read: Math.random() > 0.5, binId: b.id, zone: b.zone });
    });
    bins.filter(b => !b.sensorOk).slice(0, 3).forEach((b, i) => {
      alerts.push({ id:`OFF-${i}`, type:'info', icon:'🔵', title:'Sensor Offline',
        detail:`${b.id} in ${b.zone} not transmitting`,
        time: new Date(Date.now() - rand(1800000, 28800000)), read: true, binId: b.id, zone: b.zone });
    });
    alerts.sort((a, b) => b.time - a.time);
    return alerts;
  }

  function tick() {
    // Every bin fills at its individual rate
    bins.forEach(bin => {
      if (!bin.sensorOk) return;
      bin.fill = parseFloat(Math.min(100, bin.fill + bin.fillRate).toFixed(1));
      bin.lastUpdate = new Date();
    });
    // Trucks move
    trucks.forEach(truck => {
      if (truck.status !== 'Active') return;
      truck.lat = Math.max(-0.95, Math.min(0.95, truck.lat + (Math.random() - 0.5) * 0.05));
      truck.lng = Math.max(-0.95, Math.min(0.95, truck.lng + (Math.random() - 0.5) * 0.05));
      truck.estMinsRemaining = Math.max(0, truck.estMinsRemaining - 0.133);
    });
    assignNextStops();
    buildAlerts();
    updateCallbacks.forEach(cb => cb({ bins, trucks, alerts, kpis: getKPIs() }));
  }

  function getKPIs() {
    const online   = bins.filter(b => b.sensorOk);
    const avgFill  = parseFloat((online.reduce((s, b) => s + b.fill, 0) / (online.length || 1)).toFixed(1));
    const overflow = bins.filter(b => b.fill >= 80).length;
    const active   = trucks.filter(t => t.status === 'Active').length;
    return {
      activeBins:    online.length,
      totalBins:     bins.length,
      overflowRisk:  overflow,
      activeTrucks:  active,
      avgFill,
      co2Saved:      parseFloat((active * 12.4 + (100 - avgFill) * 0.8).toFixed(1)),
      totalCollected: trucks.reduce((s, t) => s + t.binsCollected, 0),
      unreadAlerts:  alerts.filter(a => !a.read).length,
    };
  }

  function getZoneSummary() {
    return CITIES[currentCity].zones.map(zone => {
      const zb = bins.filter(b => b.zone === zone);
      if (!zb.length) return null;
      const avg = parseFloat((zb.reduce((s, b) => s + b.fill, 0) / zb.length).toFixed(0));
      return { zone, binCount: zb.length, avgFill: avg,
        alerts: zb.filter(b => b.fill >= 80).length,
        status: avg >= 80 ? 'alert' : avg >= 60 ? 'warn' : 'ok' };
    }).filter(Boolean);
  }

  function getFillHistory(hours = 24) {
    const data = [], labels = [];
    const now = new Date(), avg = getKPIs().avgFill;
    for (let i = hours; i >= 0; i--) {
      const t = new Date(now - i * 3600000);
      labels.push(`${t.getHours().toString().padStart(2,'0')}:00`);
      const base = Math.max(10, avg - i * 0.28);
      data.push(parseFloat(Math.max(5, Math.min(100, base + (Math.random()-0.5)*6)).toFixed(1)));
    }
    return { labels, data };
  }

  function init(cityKey) {
    currentCity = cityKey || currentCity;
    generateBins(currentCity);
    generateTrucks(currentCity);
    buildAlerts();
    if (tickInterval) clearInterval(tickInterval);
    tickInterval = setInterval(tick, 8000);
    return { bins, trucks, alerts, kpis: getKPIs(), city: CITIES[currentCity] };
  }

  function timeAgo(date) {
    const s = Math.floor((Date.now() - date) / 1000);
    if (s < 60) return `${s}s ago`;
    if (s < 3600) return `${Math.floor(s/60)}m ago`;
    if (s < 86400) return `${Math.floor(s/3600)}h ago`;
    return `${Math.floor(s/86400)}d ago`;
  }

  function fillColor(pct) {
    if (pct >= 90) return '#ff4757';
    if (pct >= 75) return '#f5a623';
    if (pct >= 50) return '#3d9eff';
    return '#00e5a0';
  }

  // ── Weekly Efficiency (sample data for charts) ──────────
  function getWeeklyEfficiency() {
    return {
      labels:      ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      onTime:      [62, 68, 71, 65, 70, 58, 72],
      aiOptimized: [81, 85, 88, 83, 90, 79, 87],
    };
  }

  return {
    init,
    onUpdate: cb => updateCallbacks.push(cb),
    getKPIs, getZoneSummary, getFillHistory, getWeeklyEfficiency,
    timeAgo, fillColor, rand,
    getBins:        () => bins,
    getTrucks:      () => trucks,
    getAlerts:      () => alerts,
    getCities:      () => CITIES,
    getCurrentCity: () => currentCity,
  };
})();
