# SmartWaste Dashboard

## Login Credentials

### Admin (pre-created, only one)
| Username | Password       |
|----------|----------------|
| admin    | smartwaste7335 |

### Drivers
No default driver accounts. Admin creates them via **Dashboard → Drivers**.

### Citizens
Anyone can self-register on the login page under the Citizen tab.

---

## How to Set Up (Step by Step)

### Step 1 — Create Supabase project
1. Go to **supabase.com** → sign up free
2. Click **New project** → name it `smartwaste` → set a password → wait ~2 min

### Step 2 — Create database tables
1. In Supabase → **SQL Editor** → paste and run this:

```sql
CREATE TABLE bins (
  id TEXT PRIMARY KEY, zone TEXT DEFAULT '', type TEXT DEFAULT 'General',
  fill REAL DEFAULT 0, sensor_ok BOOLEAN DEFAULT true,
  last_update TIMESTAMPTZ DEFAULT now(),
  lat REAL DEFAULT 0, lng REAL DEFAULT 0,
  capacity INT DEFAULT 240, height REAL DEFAULT 30
);
CREATE TABLE readings (
  id BIGSERIAL PRIMARY KEY, bin_id TEXT NOT NULL,
  fill REAL NOT NULL, sensor_ok BOOLEAN DEFAULT true,
  ts TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE alerts (
  id BIGSERIAL PRIMARY KEY, bin_id TEXT NOT NULL,
  zone TEXT DEFAULT '', type TEXT DEFAULT 'warn',
  fill REAL DEFAULT 0, ts TIMESTAMPTZ DEFAULT now(), read BOOLEAN DEFAULT false
);
CREATE TABLE sensors (
  id TEXT PRIMARY KEY, bin_id TEXT NOT NULL,
  zone TEXT DEFAULT '', type TEXT DEFAULT 'General',
  height REAL DEFAULT 30, capacity INT DEFAULT 240,
  lat REAL DEFAULT 0, lng REAL DEFAULT 0,
  active BOOLEAN DEFAULT true, created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE bins     ENABLE ROW LEVEL SECURITY;
ALTER TABLE readings ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts   ENABLE ROW LEVEL SECURITY;
ALTER TABLE sensors  ENABLE ROW LEVEL SECURITY;
CREATE POLICY "allow_all_bins"     ON bins     FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_readings" ON readings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_alerts"   ON alerts   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_sensors"  ON sensors  FOR ALL USING (true) WITH CHECK (true);
```

### Step 3 — Copy your API credentials
In Supabase → **Settings → API** → copy:
- **Project URL** — looks like `https://abcdefgh.supabase.co`
- **anon / public key** — long string starting with `eyJ…`

### Step 4 — Paste credentials into the app
Open `js/supabase.js` and replace the top two lines:

```javascript
const SUPABASE_URL  = 'https://your-project.supabase.co';   // ← paste here
const SUPABASE_ANON = 'your-anon-key-here';                 // ← paste here
```

### Step 5 — Deploy to Netlify
1. Go to **netlify.com** → sign up free
2. Click **Add new site → Deploy manually**
3. Drag the entire `smartwaste/` folder into the upload box
4. Your dashboard is live at a URL like `https://smartwaste-abc123.netlify.app`

### Step 6 — Register your sensors
1. Log in as admin
2. Go to **Sensors** in the sidebar
3. Click **+ Add Sensor** for each bin
4. Fill in: Bin ID, Zone, Bin Height (measure it!), WiFi name + password
5. Click **Save Sensor** → go to **② Firmware** tab
6. Click **Copy All** → paste into Arduino IDE → upload to ESP8266

### Step 7 — Watch live data appear
Once the ESP8266 is powered on and connected to WiFi, it sends readings every 30 seconds directly to Supabase. The dashboard updates automatically every 15 seconds.

---

## File Structure
```
smartwaste/
├── index.html         ← portal selector
├── login.html         ← login & register
├── main.css           ← shared styles
├── manifest.json      ← PWA install config
├── sw.js              ← service worker
├── netlify.toml       ← Netlify routing config
├── icons/             ← app icons (192 & 512px)
├── js/
│   ├── auth.js        ← login / sessions (localStorage)
│   ├── supabase.js    ← Supabase client + data engine
│   ├── charts.js      ← canvas charts
│   └── map.js         ← canvas city map
├── admin/
│   ├── index.html     ← operations dashboard
│   ├── bins.html      ← bin monitor
│   ├── sensors.html   ← sensor management ← NEW
│   ├── routes.html    ← priority collection list
│   ├── reports.html   ← environmental reports
│   └── alerts.html    ← alert management
├── driver/
│   └── index.html     ← driver app
└── citizen/
    └── index.html     ← citizen app
```

## Architecture (No server needed!)
```
ESP8266 Bin
(any WiFi)
    │
    │  POST /rest/v1/bins (upsert)
    │  POST /rest/v1/readings
    │  POST /rest/v1/alerts
    ▼
Supabase (PostgreSQL cloud database)
    │
    │  GET /rest/v1/bins
    │  GET /rest/v1/alerts
    │  GET /rest/v1/readings
    ▼
Netlify (static dashboard)
    │
    ▼
Admin / Driver / Citizen browsers
```

No Node.js server. No backend to maintain. Everything is serverless.
