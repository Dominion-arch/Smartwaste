// SmartWaste Service Worker v2
const CACHE = 'smartwaste-v2';
const ASSETS = [
  '/',
  '/index.html',
  '/login.html',
  '/main.css',
  '/manifest.json',
  '/js/auth.js',
  '/js/supabase.js',
  '/js/charts.js',
  '/js/map.js',
  '/admin/index.html',
  '/admin/bins.html',
  '/admin/sensors.html',
  '/admin/routes.html',
  '/admin/reports.html',
  '/admin/alerts.html',
  '/driver/index.html',
  '/citizen/index.html',
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  // Supabase API calls — always network, never cache
  if (e.request.url.includes('supabase.co')) {
    e.respondWith(fetch(e.request).catch(() =>
      new Response('{"error":"Offline"}', { headers: { 'Content-Type': 'application/json' } })
    ));
    return;
  }
  // Static assets — cache first
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).then(res => {
      const clone = res.clone();
      caches.open(CACHE).then(c => c.put(e.request, clone));
      return res;
    }))
  );
});
