/* ============================================================
   SmartWaste — Charts (Vanilla Canvas, no dependencies)
   ============================================================ */

const SWCharts = (function() {

  // ── Palette ──
  const C = {
    accent:  '#00e5a0',
    warn:    '#f5a623',
    danger:  '#ff4757',
    info:    '#3d9eff',
    purple:  '#b57bee',
    bg:      '#111318',
    surface: '#181c23',
    border:  '#232830',
    text:    '#e8edf5',
    text2:   '#8b95a5',
    text3:   '#55616f',
  };

  // ── Utility ──
  function hexToRgba(hex, a) {
    const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
    return `rgba(${r},${g},${b},${a})`;
  }

  function setupCanvas(id) {
    const canvas = document.getElementById(id);
    if (!canvas) return null;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = (rect.width || canvas.offsetWidth || 400) * dpr;
    canvas.height = (canvas.height || 200) * dpr;
    ctx.scale(dpr, dpr);
    canvas.style.width = (canvas.width / dpr) + 'px';
    canvas.style.height = (canvas.height / dpr) + 'px';
    return { canvas, ctx, w: canvas.width / dpr, h: canvas.height / dpr };
  }

  // ── Line / Area Chart ──
  function lineChart(id, data, opts = {}) {
    const c = setupCanvas(id);
    if (!c) return;
    const { ctx, w, h } = c;
    const {
      labels = [], datasets = [], yMin = 0, yMax = 100,
      title = '', xStep = 6, gradient = true
    } = opts;

    ctx.clearRect(0, 0, w, h);

    const padL = 36, padR = 12, padT = 16, padB = 28;
    const chartW = w - padL - padR;
    const chartH = h - padT - padB;

    // Grid lines
    const ySteps = 4;
    ctx.strokeStyle = C.border;
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 4]);
    for (let i = 0; i <= ySteps; i++) {
      const y = padT + chartH - (i / ySteps) * chartH;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + chartW, y);
      ctx.stroke();
      // Y labels
      ctx.fillStyle = C.text3;
      ctx.font = '9px Space Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(Math.round(yMin + (i / ySteps) * (yMax - yMin)), padL - 4, y + 3);
    }
    ctx.setLineDash([]);

    // X labels
    const labelStep = Math.max(1, Math.floor(labels.length / (xStep)));
    labels.forEach((lbl, i) => {
      if (i % labelStep !== 0) return;
      const x = padL + (i / (labels.length - 1)) * chartW;
      ctx.fillStyle = C.text3;
      ctx.font = '9px Space Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(lbl, x, h - 6);
    });

    // Datasets
    datasets.forEach(ds => {
      if (!ds.data || !ds.data.length) return;
      const color = ds.color || C.accent;
      const pts = ds.data.map((v, i) => ({
        x: padL + (i / (ds.data.length - 1)) * chartW,
        y: padT + chartH - ((v - yMin) / (yMax - yMin)) * chartH
      }));

      // Filled area
      if (gradient) {
        const grad = ctx.createLinearGradient(0, padT, 0, padT + chartH);
        grad.addColorStop(0, hexToRgba(color, 0.25));
        grad.addColorStop(1, hexToRgba(color, 0.0));
        ctx.beginPath();
        ctx.moveTo(pts[0].x, padT + chartH);
        pts.forEach(p => ctx.lineTo(p.x, p.y));
        ctx.lineTo(pts[pts.length-1].x, padT + chartH);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();
      }

      // Line
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round';
      pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
      ctx.stroke();

      // Dots on overflow points
      pts.forEach((p, i) => {
        if (ds.data[i] >= 80) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
          ctx.fillStyle = C.danger;
          ctx.fill();
        }
      });
    });
  }

  // ── Bar Chart ──
  function barChart(id, labels, datasets, opts = {}) {
    const c = setupCanvas(id);
    if (!c) return;
    const { ctx, w, h } = c;
    const { yMax = 100, colors = [C.accent, C.info] } = opts;

    ctx.clearRect(0, 0, w, h);

    const padL = 32, padR = 12, padT = 12, padB = 24;
    const chartW = w - padL - padR;
    const chartH = h - padT - padB;
    const barGroupW = chartW / labels.length;
    const barW = (barGroupW / (datasets.length + 1)) * 0.85;

    // Grid
    [0, 25, 50, 75, 100].forEach(v => {
      const y = padT + chartH - (v / yMax) * chartH;
      ctx.strokeStyle = C.border;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 4]);
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + chartW, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = C.text3;
      ctx.font = '9px Space Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(v, padL - 4, y + 3);
    });

    datasets.forEach((ds, dsIdx) => {
      labels.forEach((lbl, lIdx) => {
        const val = Math.min(ds.data[lIdx] || 0, yMax);
        const barH = (val / yMax) * chartH;
        const x = padL + lIdx * barGroupW + dsIdx * (barW + 2) + 4;
        const y = padT + chartH - barH;
        const color = colors[dsIdx] || C.accent;

        // Bar with rounded top
        const rad = Math.min(3, barH / 2);
        ctx.beginPath();
        ctx.moveTo(x + rad, y);
        ctx.lineTo(x + barW - rad, y);
        ctx.quadraticCurveTo(x + barW, y, x + barW, y + rad);
        ctx.lineTo(x + barW, y + barH);
        ctx.lineTo(x, y + barH);
        ctx.lineTo(x, y + rad);
        ctx.quadraticCurveTo(x, y, x + rad, y);
        ctx.closePath();
        ctx.fillStyle = hexToRgba(color, 0.8);
        ctx.fill();
      });
    });

    // X labels
    labels.forEach((lbl, i) => {
      const x = padL + i * barGroupW + barGroupW / 2;
      ctx.fillStyle = C.text3;
      ctx.font = '9px Space Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(lbl, x, h - 6);
    });

    // Legend
    if (datasets.length > 1) {
      datasets.forEach((ds, i) => {
        ctx.fillStyle = colors[i] || C.accent;
        ctx.fillRect(padL + i * 80, 4, 10, 6);
        ctx.fillStyle = C.text3;
        ctx.font = '9px Space Mono, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(ds.label || '', padL + i * 80 + 14, 10);
      });
    }
  }

  // ── Sparkline ──
  function sparkline(containerId, data, color = '#00e5a0') {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '';
    const canvas = document.createElement('canvas');
    canvas.width = container.offsetWidth || 100;
    canvas.height = 30;
    container.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const min = Math.min(...data), max = Math.max(...data);
    const range = max - min || 1;

    const pts = data.map((v, i) => ({
      x: (i / (data.length - 1)) * w,
      y: h - ((v - min) / range) * (h - 4) - 2
    }));

    // Gradient fill
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, hexToRgba(color, 0.3));
    grad.addColorStop(1, hexToRgba(color, 0));
    ctx.beginPath();
    ctx.moveTo(0, h);
    pts.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();
  }

  // ── Donut Chart ──
  function donutChart(id, segments, opts = {}) {
    const c = setupCanvas(id);
    if (!c) return;
    const { ctx, w, h } = c;
    const { centerLabel = '', centerSub = '' } = opts;

    ctx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    const r = Math.min(cx, cy) - 10;
    const ir = r * 0.6;
    const total = segments.reduce((s, seg) => s + seg.value, 0);

    let angle = -Math.PI / 2;
    segments.forEach(seg => {
      const slice = (seg.value / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, angle, angle + slice);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      angle += slice;
    });

    // Inner circle (cutout)
    ctx.beginPath();
    ctx.arc(cx, cy, ir, 0, Math.PI * 2);
    ctx.fillStyle = '#111318';
    ctx.fill();

    // Center text
    if (centerLabel) {
      ctx.fillStyle = C.text;
      ctx.font = `bold 20px Syne, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(centerLabel, cx, cy - 6);
      if (centerSub) {
        ctx.fillStyle = C.text3;
        ctx.font = '10px Space Mono, monospace';
        ctx.fillText(centerSub, cx, cy + 14);
      }
    }

    // Legend
    const legX = 10, legY = h - 10 - segments.length * 14;
    segments.forEach((seg, i) => {
      ctx.fillStyle = seg.color;
      ctx.fillRect(legX, legY + i * 14, 8, 8);
      ctx.fillStyle = C.text3;
      ctx.font = '9px Space Mono, monospace';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(`${seg.label} ${Math.round(seg.value / total * 100)}%`, legX + 12, legY + i * 14);
    });
  }

  // ── Horizontal bar ──
  function hBar(id, labels, values, opts = {}) {
    const c = setupCanvas(id);
    if (!c) return;
    const { ctx, w, h } = c;
    const colors = opts.colors || labels.map((_, i) => [C.accent, C.info, C.warn, C.danger, C.purple][i % 5]);
    const maxVal = opts.maxVal || Math.max(...values) * 1.1;

    ctx.clearRect(0, 0, w, h);
    const padL = 90, padR = 40, padT = 10, barH = 16, gap = 8;

    labels.forEach((lbl, i) => {
      const y = padT + i * (barH + gap);
      const barW = (values[i] / maxVal) * (w - padL - padR);
      const color = colors[i];

      // Label
      ctx.fillStyle = C.text2;
      ctx.font = '11px Syne, sans-serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.fillText(lbl, padL - 8, y + barH / 2);

      // Background track
      ctx.fillStyle = '#1e242e';
      ctx.beginPath();
      ctx.roundRect(padL, y, w - padL - padR, barH, 4);
      ctx.fill();

      // Value bar
      ctx.fillStyle = hexToRgba(color, 0.85);
      ctx.beginPath();
      ctx.roundRect(padL, y, Math.max(barW, 4), barH, 4);
      ctx.fill();

      // Value label
      ctx.fillStyle = C.text2;
      ctx.font = '10px Space Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(values[i] + (opts.unit || ''), padL + barW + 6, y + barH / 2);
    });
  }

  return { lineChart, barChart, sparkline, donutChart, hBar };
})();
