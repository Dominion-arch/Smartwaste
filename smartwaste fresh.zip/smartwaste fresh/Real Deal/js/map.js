/* ============================================================
   SmartWaste — City Map (Canvas)
   ============================================================ */

const SWMap = (function() {
  let canvas, ctx, tooltip;
  let bins = [], trucks = [];
  let hoveredItem = null;
  let animFrame = null;
  let pulsePhase = 0;

  // Fake street grid points (relative, -1 to 1)
  const STREET_GRID = [
    // Horizontals
    {x1:-1,y1:-0.6,x2:1,y2:-0.6},{x1:-1,y1:-0.2,x2:1,y2:-0.2},
    {x1:-1,y1:0.1,x2:1,y2:0.1},{x1:-1,y1:0.5,x2:1,y2:0.5},
    // Verticals
    {x1:-0.7,y1:-1,x2:-0.7,y2:1},{x1:-0.3,y1:-1,x2:-0.3,y2:1},
    {x1:0.1,y1:-1,x2:0.1,y2:1},{x1:0.5,y1:-1,x2:0.5,y2:1},
    {x1:0.8,y1:-1,x2:0.8,y2:1},
    // Diagonals (main roads)
    {x1:-1,y1:0.8,x2:1,y2:-0.4},{x1:-1,y1:-0.8,x2:0.6,y2:0.8},
  ];

  function init() {
    canvas = document.getElementById('mapCanvas');
    if (!canvas) return;
    ctx = canvas.getContext('2d');
    tooltip = document.getElementById('map-tooltip');

    // Responsive size
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseleave', () => {
      hoveredItem = null;
      if (tooltip) tooltip.style.display = 'none';
    });

    render();
  }

  function resizeCanvas() {
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    canvas.width = rect.width || 600;
    canvas.height = Math.min(340, rect.width * 0.56);
  }

  function project(relX, relY) {
    const margin = 24;
    const x = margin + (relX + 1) / 2 * (canvas.width - margin * 2);
    const y = margin + (relY + 1) / 2 * (canvas.height - margin * 2);
    return { x, y };
  }

  function render() {
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pulsePhase += 0.04;

    // Background
    ctx.fillStyle = '#111318';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid / streets
    ctx.strokeStyle = '#1e242e';
    ctx.lineWidth = 1;
    STREET_GRID.forEach(s => {
      const p1 = project(s.x1, s.y1);
      const p2 = project(s.x2, s.y2);
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    });

    // Bins
    bins.forEach(bin => {
      if (!bin.lat || !bin.lng) return;
      const p = project(bin.lng, bin.lat);
      const color = fillColor(bin.fill);
      const r = bin.fill >= 80 ? 7 : 5;

      // Glow for overflow
      if (bin.fill >= 80) {
        const pulse = Math.sin(pulsePhase) * 0.4 + 0.6;
        ctx.beginPath();
        ctx.arc(p.x, p.y, r + 5, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(color, 0.15 * pulse);
        ctx.fill();
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();

      // Fill level ring
      if (bin.fill >= 50) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, r + 2, -Math.PI / 2, -Math.PI / 2 + (bin.fill / 100) * Math.PI * 2);
        ctx.strokeStyle = hexToRgba(color, 0.5);
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    });

    // Trucks
    trucks.forEach(truck => {
      if (!truck.lat || !truck.lng) return;
      const p = project(truck.lng, truck.lat);
      if (truck.status === 'Idle') return;

      // Truck icon (triangle)
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - 9);
      ctx.lineTo(p.x + 7, p.y + 6);
      ctx.lineTo(p.x - 7, p.y + 6);
      ctx.closePath();
      ctx.fillStyle = truck.color || '#b57bee';
      ctx.fill();

      // Label
      ctx.fillStyle = '#ffffff';
      ctx.font = '8px Space Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(truck.id.replace('TRK-','T'), p.x, p.y + 18);
    });

    // Legend watermark
    ctx.fillStyle = '#232830';
    ctx.font = '10px Space Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText('SMARTWASTE LIVE MAP', 10, canvas.height - 8);

    animFrame = requestAnimationFrame(render);
  }

  function fillColor(pct) {
    if (pct >= 90) return '#ff4757';
    if (pct >= 75) return '#f5a623';
    if (pct >= 50) return '#3d9eff';
    return '#00e5a0';
  }

  function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1,3),16);
    const g = parseInt(hex.slice(3,5),16);
    const b = parseInt(hex.slice(5,7),16);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function onMouseMove(e) {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    let found = null;
    bins.forEach(bin => {
      if (!bin.lat || !bin.lng) return;
      const p = project(bin.lng, bin.lat);
      const dx = mx - p.x, dy = my - p.y;
      if (Math.sqrt(dx*dx + dy*dy) < 10) found = { ...bin, px: p.x, py: p.y };
    });

    if (found && tooltip) {
      tooltip.style.display = 'block';
      tooltip.style.left = (found.px + 12) + 'px';
      tooltip.style.top = (found.py - 10) + 'px';
      tooltip.innerHTML = `
        <strong>${found.id}</strong><br/>
        ${found.zone} · ${found.type}<br/>
        Fill: <span style="color:${fillColor(found.fill)}">${found.fill}%</span><br/>
        Temp: ${found.temperature}°C
      `;
    } else if (tooltip) {
      tooltip.style.display = 'none';
    }
  }

  function update(newBins, newTrucks) {
    bins = newBins;
    trucks = newTrucks;
  }

  function destroy() {
    if (animFrame) cancelAnimationFrame(animFrame);
  }

  return { init, update, destroy };
})();
