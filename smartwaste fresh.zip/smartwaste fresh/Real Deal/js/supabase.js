/* ============================================================
   SmartWaste — Supabase Client & Data Engine v3
   
   SETUP: Replace the two values below with your project's
   URL and anon key from https://supabase.com/dashboard
   ============================================================ */

// !! CHANGE THESE TWO LINES with your Supabase project details !!
const SUPABASE_URL    = 'https://mbvaxutvtvamczlmcjdo.supabase.co';
const SUPABASE_ANON   = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1idmF4dXR2dHZhbWN6bG1jamRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA2NzYzMDYsImV4cCI6MjA5NjI1MjMwNn0.rUA8fHNlcF5xL0XpuOnvHdRbEYvmrELxL_A3qwbVrj0';

// ── Low-level fetch wrapper around Supabase REST API ─────
const SB = {
  headers: {
    'apikey':        SUPABASE_ANON,
    'Authorization': `Bearer ${SUPABASE_ANON}`,
    'Content-Type':  'application/json',
    'Prefer':        'return=representation',
  },

  async get(table, params = '') {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, { headers: this.headers });
    if (!r.ok) throw new Error(`SB.get ${table}: ${r.status}`);
    return r.json();
  },

  async post(table, body) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method: 'POST', headers: this.headers, body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`SB.post ${table}: ${r.status}`);
    return r.json();
  },

  async patch(table, params, body) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, {
      method: 'PATCH', headers: { ...this.headers, Prefer: 'return=representation' },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`SB.patch ${table}: ${r.status}`);
    return r.json();
  },

  async upsert(table, body, onConflict = 'id') {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?on_conflict=${onConflict}`, {
      method: 'POST',
      headers: { ...this.headers, Prefer: `resolution=merge-duplicates,return=representation` },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`SB.upsert ${table}: ${r.status}`);
    return r.json();
  },

  async delete(table, params) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, {
      method: 'DELETE', headers: this.headers,
    });
    if (!r.ok) throw new Error(`SB.delete ${table}: ${r.status}`);
    return r.json();
  },

  // Realtime subscription via Supabase Realtime websocket
  subscribe(table, callback) {
    const ws = new WebSocket(
      `${SUPABASE_URL.replace('https', 'wss')}/realtime/v1/websocket?apikey=${SUPABASE_ANON}&vsn=1.0.0`
    );
    ws.onopen = () => {
      ws.send(JSON.stringify({
        topic: `realtime:public:${table}`,
        event: 'phx_join',
        payload: {},
        ref: '1',
      }));
    };
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (msg.event === 'INSERT' || msg.event === 'UPDATE') callback(msg.payload?.record);
    };
    return ws; // caller can ws.close() to unsubscribe
  },
};

/* ============================================================
   SmartWaste — Live Data Engine (Supabase backend)
   Same public API as the old data.js so no dashboard code
   needs to change.
   ============================================================ */
const SW = (function () {
  let bins    = [];
  let alerts  = [];
  let zones   = [];
  let history = { labels: [], data: [] };
  let kpis    = { activeBins:0, totalBins:0, overflowRisk:0, activeTrucks:0, avgFill:0, unreadAlerts:0 };
  let updateCallbacks = [];
  let pollInterval    = null;
  let realtimeWs      = null;
  let connected       = false;

  // ── Fetch everything from Supabase ───────────────────────
  async function fetchAll() {
    try {
      // Parallel fetch: bins + recent alerts + fill history
      const [rawBins, rawAlerts, rawHistory] = await Promise.all([
        SB.get('bins', '?select=*&order=fill.desc'),
        SB.get('alerts', '?select=*&order=ts.desc&limit=100'),
        SB.get('readings',
          `?select=ts,fill&order=ts.asc&ts=gte.${new Date(Date.now()-86400000).toISOString()}&limit=200`
        ),
      ]);

      // Normalise bins
      bins = rawBins.map(b => ({
        id:         b.id,
        zone:       b.zone       || '—',
        type:       b.type       || 'General',
        fill:       parseFloat(parseFloat(b.fill).toFixed(1)),
        sensorOk:   b.sensor_ok !== false,
        lastUpdate: new Date(b.last_update || Date.now()),
        lat:        parseFloat(b.lat) || 0,
        lng:        parseFloat(b.lng) || 0,
        capacity:   b.capacity   || 240,
        height:     b.height     || 30,
        temperature:'—',
      }));

      // Normalise alerts
      alerts = rawAlerts.map(a => ({
        id:     a.id,
        bin_id: a.bin_id,
        zone:   a.zone  || '—',
        type:   a.type  || 'warn',
        fill:   a.fill  || 0,
        ts:     a.ts,
        read:   a.read  || false,
        icon:   a.type === 'danger' ? '🔴' : '🟡',
        title:  a.type === 'danger' ? 'Bin Overflow' : 'High Fill Level',
        detail: `${a.bin_id} in ${a.zone || '—'} at ${a.fill}%`,
      }));

      // Build fill history (hourly averages)
      const byHour = {};
      rawHistory.forEach(r => {
        const h = new Date(r.ts).getHours().toString().padStart(2,'0') + ':00';
        if (!byHour[h]) byHour[h] = [];
        byHour[h].push(r.fill);
      });
      const sortedHours = Object.keys(byHour).sort();
      history = {
        labels: sortedHours,
        data:   sortedHours.map(h => parseFloat((byHour[h].reduce((s,v)=>s+v,0)/byHour[h].length).toFixed(1))),
      };

      // Derive zone summaries from bins
      const zoneMap = {};
      bins.forEach(b => {
        if (!zoneMap[b.zone]) zoneMap[b.zone] = [];
        zoneMap[b.zone].push(b);
      });
      zones = Object.entries(zoneMap).map(([zone, zb]) => {
        const avg = parseFloat((zb.reduce((s,b)=>s+b.fill,0)/zb.length).toFixed(1));
        return { zone, binCount: zb.length, avgFill: avg, alerts: zb.filter(b=>b.fill>=80).length, status: avg>=80?'alert':avg>=60?'warn':'ok' };
      }).sort((a,b)=>b.avgFill-a.avgFill);

      // KPIs
      const online = bins.filter(b => b.sensorOk);
      const avgFill = online.length ? parseFloat((online.reduce((s,b)=>s+b.fill,0)/online.length).toFixed(1)) : 0;
      kpis = {
        totalBins:    bins.length,
        activeBins:   online.length,
        avgFill,
        overflowRisk: bins.filter(b=>b.fill>=80).length,
        activeTrucks: 0,
        unreadAlerts: alerts.filter(a=>!a.read).length,
      };

      connected = true;
      _setStatus('connected');
      updateCallbacks.forEach(cb => cb({ bins, alerts, kpis }));

    } catch (err) {
      connected = false;
      _setStatus('disconnected');
      console.warn('[SW] Supabase fetch error:', err.message);
      updateCallbacks.forEach(cb => cb({ bins, alerts, kpis }));
    }
  }

  function _avg(arr) {
    return !arr.length ? 0 : parseFloat((arr.reduce((s,v)=>s+v,0)/arr.length).toFixed(1));
  }

  function _setStatus(state) {
    const live = state === 'connected';
    document.querySelectorAll('.conn-status').forEach(el => {
      el.textContent = live ? 'LIVE' : 'OFFLINE';
      el.style.color = live ? 'var(--accent)' : 'var(--danger)';
    });
    document.querySelectorAll('.pulse-dot').forEach(el => {
      el.style.background = live ? 'var(--accent)' : 'var(--danger)';
    });
  }

  // ── Public actions ────────────────────────────────────────
  async function acknowledgeAlert(alertId) {
    try { await SB.patch('alerts', `?id=eq.${alertId}`, { read: true }); }
    catch (e) { console.warn('ack alert failed:', e.message); }
  }

  // ── Public API ────────────────────────────────────────────
  function init() {
    fetchAll();
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = setInterval(fetchAll, 15000);
    return { bins, alerts, kpis };
  }

  function timeAgo(date) {
    if (!date) return '—';
    const s = Math.floor((Date.now() - new Date(date)) / 1000);
    if (s < 60)    return `${s}s ago`;
    if (s < 3600)  return `${Math.floor(s/60)}m ago`;
    if (s < 86400) return `${Math.floor(s/3600)}h ago`;
    return `${Math.floor(s/86400)}d ago`;
  }

  function fillColor(pct) {
    if (pct >= 90) return '#ff4757';
    if (pct >= 75) return '#f5a623';
    if (pct >= 50) return '#3d9eff';
    return '#00e5a0';
  }

  return {
    init,
    onUpdate:        cb  => updateCallbacks.push(cb),
    getKPIs:         ()  => kpis,
    getBins:         ()  => bins,
    getAlerts:       ()  => alerts,
    getTrucks:       ()  => [],
    getCities:       ()  => ({}),
    getCurrentCity:  ()  => 'sunyani',
    getZoneSummary:  ()  => zones,
    getFillHistory:  ()  => history,
    getWeeklyEfficiency: () => ({
      labels:      ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      onTime:      [0,0,0,0,0,0,0],
      aiOptimized: [0,0,0,0,0,0,0],
    }),
    acknowledgeAlert,
    timeAgo,
    fillColor,
    isConnected: () => connected,
    rand: (a, b) => Math.floor(Math.random() * (b - a + 1)) + a,

    // Sensor management (used by admin sensors page)
    sensors: {
      async getAll() {
        return SB.get('sensors', '?select=*&order=created_at.desc');
      },
      async register(data) {
        return SB.upsert('sensors', {
          id:       data.id,
          bin_id:   data.binId,
          zone:     data.zone,
          type:     data.type,
          height:   parseFloat(data.height),
          capacity: parseInt(data.capacity),
          lat:      parseFloat(data.lat) || 0,
          lng:      parseFloat(data.lng) || 0,
          active:   true,
          created_at: new Date().toISOString(),
        }, 'id');
      },
      async deactivate(sensorId) {
        return SB.patch('sensors', `?id=eq.${sensorId}`, { active: false });
      },
      async delete(sensorId) {
        return SB.delete('sensors', `?id=eq.${sensorId}`);
      },
    },
  };
})();
