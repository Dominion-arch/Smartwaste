/* ============================================================
   SmartWaste — Auth Engine v2
   Roles: admin | driver | citizen
   No demo users. Admin account only. Drivers created by admin.
   Citizens self-register.
   ============================================================ */

const SWAuth = (function () {

  const KEYS = { users: 'sw_users', session: 'sw_session' };

  // ── Seed only the admin account on first load ─────────────
  function seedData() {
    if (localStorage.getItem(KEYS.users)) return;
    const users = [{
      id:        'admin-001',
      username:  'admin',
      password:  'smartwaste7335',
      role:      'admin',
      name:      'City Administrator',
      email:     'admin@smartwaste.gh',
      createdAt: new Date().toISOString(),
    }];
    localStorage.setItem(KEYS.users, JSON.stringify(users));
  }

  // ── Storage helpers ───────────────────────────────────────
  function getUsers()       { return JSON.parse(localStorage.getItem(KEYS.users) || '[]'); }
  function saveUsers(u)     { localStorage.setItem(KEYS.users, JSON.stringify(u)); }
  function getSession()     { const s = localStorage.getItem(KEYS.session); return s ? JSON.parse(s) : null; }
  function saveSession(u)   { localStorage.setItem(KEYS.session, JSON.stringify({ ...u, loginTime: new Date().toISOString() })); }
  function clearSession()   { localStorage.removeItem(KEYS.session); }

  // ── Login ─────────────────────────────────────────────────
  function login(username, password) {
    const user = getUsers().find(u =>
      u.username.toLowerCase() === username.toLowerCase().trim() && u.password === password
    );
    if (!user) return { ok: false, error: 'Invalid username or password.' };
    saveSession(user);
    return { ok: true, user };
  }

  function logout() { clearSession(); }

  // ── Citizen self-registration ─────────────────────────────
  function register(data) {
    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === data.username.toLowerCase().trim()))
      return { ok: false, error: 'Username already taken.' };
    if (users.find(u => u.email && u.email.toLowerCase() === data.email.toLowerCase().trim()))
      return { ok: false, error: 'Email already registered.' };
    const newUser = {
      id:               'ctz-' + Date.now(),
      username:         data.username.trim(),
      password:         data.password,
      role:             'citizen',
      name:             data.name.trim(),
      email:            data.email.trim(),
      createdAt:        new Date().toISOString(),
      zone:             data.zone || '',
      ecoScore:         0,
      reportsSubmitted: 0,
      pickupsScheduled: 0,
    };
    users.push(newUser);
    saveUsers(users);
    saveSession(newUser);
    return { ok: true, user: newUser };
  }

  // ── Admin: create driver ──────────────────────────────────
  function adminCreateDriver(data) {
    const session = getSession();
    if (!session || session.role !== 'admin') return { ok: false, error: 'Unauthorized.' };
    const users = getUsers();
    if (users.find(u => u.username.toLowerCase() === data.username.toLowerCase().trim()))
      return { ok: false, error: 'Username already taken.' };
    const driver = {
      id:                 'drv-' + Date.now(),
      username:           data.username.trim(),
      password:           data.password,
      role:               'driver',
      name:               data.name.trim(),
      email:              (data.email || '').trim(),
      createdAt:          new Date().toISOString(),
      truckId:            data.truckId || '',
      route:              data.route || '',
      zone:               data.zone || '',
      binsCollectedTotal: 0,
    };
    users.push(driver);
    saveUsers(users);
    return { ok: true, user: driver };
  }

  // ── Admin: delete driver ──────────────────────────────────
  function deleteDriver(driverId) {
    const session = getSession();
    if (!session || session.role !== 'admin') return { ok: false, error: 'Unauthorized.' };
    let users = getUsers();
    if (!users.find(u => u.id === driverId && u.role === 'driver'))
      return { ok: false, error: 'Driver not found.' };
    saveUsers(users.filter(u => u.id !== driverId));
    return { ok: true };
  }

  // ── Admin: update driver ──────────────────────────────────
  function updateDriver(driverId, fields) {
    const session = getSession();
    if (!session || session.role !== 'admin') return { ok: false, error: 'Unauthorized.' };
    const users = getUsers();
    const idx = users.findIndex(u => u.id === driverId && u.role === 'driver');
    if (idx === -1) return { ok: false, error: 'Driver not found.' };
    users[idx] = { ...users[idx], ...fields };
    saveUsers(users);
    return { ok: true, user: users[idx] };
  }

  // ── Getters ───────────────────────────────────────────────
  function getDrivers()  { return getUsers().filter(u => u.role === 'driver'); }
  function getCitizens() { return getUsers().filter(u => u.role === 'citizen'); }

  // ── Route guard ───────────────────────────────────────────
  function requireRole(role) {
    const session = getSession();
    if (!session) { window.location.href = _loginUrl(role); return null; }
    if (session.role !== role) { _redirectPortal(session.role); return null; }
    return session;
  }

  function _loginUrl(role) {
    const depth = window.location.pathname.split('/').filter(Boolean).length;
    return (depth <= 1 ? '' : '../') + `login.html?portal=${role || 'citizen'}`;
  }

  function _redirectPortal(role) {
    const depth = window.location.pathname.split('/').filter(Boolean).length;
    const pre = depth <= 1 ? '' : '../';
    const map = { admin: 'admin/index.html', driver: 'driver/index.html', citizen: 'citizen/index.html' };
    window.location.href = pre + (map[role] || '');
  }

  function init() { seedData(); }

  return {
    init, login, logout, register,
    adminCreateDriver, deleteDriver, updateDriver,
    getSession, getDrivers, getCitizens, getUsers,
    requireRole,
  };
})();

SWAuth.init();
